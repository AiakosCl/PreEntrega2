from setuptools import setup

setup (
    name = "ModeloCliente",
    version = "1.0",
    packages = ["ModeloCliente"]
)